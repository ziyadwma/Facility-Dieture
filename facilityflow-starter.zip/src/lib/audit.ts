import { prisma } from './prisma'
export async function audit(actorId:string, entityType:string, entityId:string, action:string, before:any, after:any){
  await prisma.auditEvent.create({ data:{ actorId, entityType, entityId, action, before, after } })
}
