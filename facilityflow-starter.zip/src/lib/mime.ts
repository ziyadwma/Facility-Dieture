export function isAllowedPhoto(mime:string){ return ['image/jpeg','image/png','image/webp'].includes(mime) }
