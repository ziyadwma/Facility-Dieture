import Twilio from 'twilio'
const tw = Twilio(process.env.TWILIO_ACCOUNT_SID!, process.env.TWILIO_AUTH_TOKEN!)
export async function sendSMS(to:string, body:string){
  await tw.messages.create({ to, from: process.env.TWILIO_FROM_NUMBER!, body })
}
