import { Queue } from 'bullmq'
import IORedis from 'ioredis'
const connection = new IORedis(process.env.REDIS_URL!)
export const q = new Queue('facilityflow', { connection })
export async function enqueue(type:string, payload:any & { when:Date }){
  await q.add(type, payload, { delay: Math.max(0, payload.when.getTime()-Date.now()) })
}
