import { z } from 'zod'
export const IssueCreateSchema = z.object({
  title: z.string().min(3).max(120),
  description: z.string().min(5).max(4000),
  areaId: z.string().cuid(),
  locationNote: z.string().max(200).optional(),
  departmentId: z.string().cuid(),
  priority: z.enum(['P1','P2','P3','P4']).optional(),
  photos: z.array(z.object({ name:z.string(), size:z.number().max(parseInt(process.env.MAX_PHOTO_BYTES||'1048576')), type:z.string() })).max(10)
})
export const ETASetSchema = z.object({ issueId:z.string().cuid(), etaAt:z.coerce.date(), note:z.string().max(500).optional() })
export const WorkLogSchema = z.object({ issueId:z.string().cuid(), start:z.coerce.date(), stop:z.coerce.date(), notes:z.string().max(500).optional() })
export const PurchaseRequestSchema = z.object({
  issueId: z.string().cuid(),
  items: z.array(z.object({ sku:z.string().optional(), name:z.string().min(1), qty:z.number().int().positive(), unitCost:z.number().nonnegative().optional() })).min(1),
  estimate: z.number().nonnegative().optional(),
  vendor: z.string().optional()
})
