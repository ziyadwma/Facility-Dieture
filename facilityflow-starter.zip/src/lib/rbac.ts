import { Role } from '@prisma/client'
export type SessionUser = { id:string; role:Role; departmentId?:string|null }
export const can = {
  createIssue: (u:SessionUser)=> !!u,
  viewIssue: (u:SessionUser, issue:{ reporterId:string; departmentId:string })=>{
    if (u.role === 'Admin' || u.role === 'OperationsManager') return true
    if (u.role === 'DepartmentManager' || u.role === 'Technician') return u.departmentId === issue.departmentId
    if (u.role === 'Requester') return issue.reporterId === u.id
    return false
  },
  triage: (u:SessionUser)=> ['Admin','OperationsManager','DepartmentManager'].includes(u.role),
  assign: (u:SessionUser)=> ['Admin','OperationsManager','DepartmentManager'].includes(u.role),
  technicianActions: (u:SessionUser)=> u.role==='Technician' || u.role==='Admin' || u.role==='OperationsManager',
  approvePR: (u:SessionUser)=> u.role==='OperationsManager' || u.role==='Admin',
}
