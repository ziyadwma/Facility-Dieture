import { differenceInMilliseconds } from 'date-fns'
export function ackTarget(createdAt:Date){ return new Date(createdAt.getTime() + 24*60*60*1000) }
export function repairAlert(assignedAt:Date){ return new Date(assignedAt.getTime() + 72*60*60*1000) }
export function repairWallClock(resolvedAt:Date, assignedAt:Date, pausedMs:number){ return differenceInMilliseconds(resolvedAt, assignedAt) - pausedMs }
export function totalCycle(closedAt:Date, createdAt:Date){ return differenceInMilliseconds(closedAt, createdAt) }
