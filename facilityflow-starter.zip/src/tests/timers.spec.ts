import { describe, it, expect } from 'vitest'
import { ackTarget, repairAlert } from '@/lib/sla'

describe('SLA timers', ()=>{
  it('ack 24h', ()=>{
    const t = new Date('2025-01-01T00:00:00Z')
    expect(ackTarget(t).getTime()-t.getTime()).toBe(24*60*60*1000)
  })
  it('repair 72h', ()=>{
    const t = new Date('2025-01-01T00:00:00Z')
    expect(repairAlert(t).getTime()-t.getTime()).toBe(72*60*60*1000)
  })
})
