import { prisma } from '@/lib/prisma'
export default async function Reports(){
  const issues = await prisma.issue.findMany({ where:{ closedAt: { not: null } }, select:{ createdAt:true, acknowledgedAt:true, assignedAt:true, resolvedAt:true, closedAt:true } })
  const rows = issues.map(i=>{
    const timeToAck = i.acknowledgedAt ? (i.acknowledgedAt.getTime()-i.createdAt.getTime()) : null
    const repairWall = (i.resolvedAt && i.assignedAt) ? (i.resolvedAt.getTime()-i.assignedAt.getTime()) : null
    const total = i.closedAt ? (i.closedAt.getTime()-i.createdAt.getTime()) : null
    return { timeToAck, repairWall, total }
  })
  return <pre>{JSON.stringify(rows,null,2)}</pre>
}
