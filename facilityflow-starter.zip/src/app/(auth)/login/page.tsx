'use client'
export default function Page(){
  return (
    <div className="min-h-screen grid place-items-center p-6">
      <div className="w-full max-w-md p-6 rounded-2xl border">
        <h1 className="text-2xl font-semibold mb-2">FacilityFlow</h1>
        <p className="text-sm opacity-80 mb-4">Sign in to manage facility issues</p>
        <div className="grid gap-2">
          <button className="border rounded px-3 py-2">Continue with Google</button>
          <button className="border rounded px-3 py-2">Microsoft</button>
          <button className="border rounded px-3 py-2">Email link</button>
        </div>
      </div>
    </div>
  )
}
