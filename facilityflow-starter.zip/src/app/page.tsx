import { prisma } from '@/lib/prisma'
export default async function Dashboard(){
  const [breaches, etaOverdue] = await Promise.all([
    prisma.issue.count({ where:{ OR:[ { breachAck:true }, { breachRepair:true } ] } }),
    prisma.issue.count({ where:{ etaAt: { lte: new Date() }, NOT:{ status: { in:['Resolved','Closed'] } } } }),
  ])
  return (
    <div className="p-6 grid gap-6">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="rounded-2xl p-4 shadow bg-white/5">Breaches: {breaches}</div>
        <div className="rounded-2xl p-4 shadow bg-white/5">Overdue ETAs: {etaOverdue}</div>
      </div>
    </div>
  )
}
