'use server'
import { prisma } from '@/lib/prisma'
import { IssueCreateSchema, ETASetSchema } from '@/lib/validation'
import { ackTarget, repairAlert } from '@/lib/sla'
import { audit } from '@/lib/audit'
import { isAllowedPhoto } from '@/lib/mime'
import { enqueue } from '@/lib/queue'

export async function createIssue(formData:FormData){
  // TODO: get session user from NextAuth
  const user = { id: 'demo-user' }
  const payload:any = {
    title: formData.get('title'),
    description: formData.get('description'),
    areaId: formData.get('areaId'),
    locationNote: formData.get('locationNote')||undefined,
    departmentId: formData.get('departmentId'),
    priority: formData.get('priority')||'P3',
  }
  const parsed = IssueCreateSchema.safeParse({ ...payload, photos: [] })
  if (!parsed.success) throw new Error(parsed.error.message)

  const issue = await prisma.$transaction(async(tx)=>{
    const created = await tx.issue.create({ data:{ ...payload, reporterId: user.id } })
    const ackAt = ackTarget(created.createdAt)
    await tx.sLA.create({ data:{ issueId: created.id, ackTargetAt: ackAt, repairAlertAt: created.assignedAt ? repairAlert(created.assignedAt) : created.createdAt } })
    await tx.issue.update({ where:{id:created.id}, data:{ ackTargetAt: ackAt } })
    await audit(user.id,'Issue', created.id, 'Create', null, created)
    return created
  })
  await enqueue('ackReminder', { issueId: issue.id, when: new Date(issue.ackTargetAt!.getTime()-60*60*1000) })
  await enqueue('ackBreach', { issueId: issue.id, when: issue.ackTargetAt! })
  return issue
}

export async function assignTechnician(issueId:string, technicianId:string){
  const before = await prisma.issue.findUniqueOrThrow({ where:{id:issueId} })
  const assignedAt = new Date()
  const updated = await prisma.issue.update({ where:{id:issueId}, data:{ status:'Assigned', assignedAt, assignedToId: technicianId, repairAlertAt: repairAlert(assignedAt) }})
  await prisma.sLA.upsert({ where:{ issueId }, update:{ repairAlertAt: updated.repairAlertAt! }, create:{ issueId, ackTargetAt: before.ackTargetAt ?? new Date(), repairAlertAt: updated.repairAlertAt! } })
  await audit('system','Issue', issueId,'Assign', before, updated)
  await enqueue('repairAlert', { issueId, when: updated.repairAlertAt! })
  return updated
}

export async function setETA(data:any){
  const parsed = ETASetSchema.parse(data)
  const before = await prisma.issue.findUniqueOrThrow({ where:{ id: parsed.issueId } })
  const updated = await prisma.issue.update({ where:{ id: parsed.issueId }, data:{ etaAt: parsed.etaAt } })
  await audit('system','Issue', parsed.issueId,'SetETA', before, updated)
  await enqueue('etaOverdue', { issueId: parsed.issueId, when: parsed.etaAt })
  return updated
}
