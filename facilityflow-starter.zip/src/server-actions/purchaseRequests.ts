'use server'
import { prisma } from '@/lib/prisma'
import { PurchaseRequestSchema } from '@/lib/validation'
import { audit } from '@/lib/audit'

export async function createPR(input:any){
  const parsed = PurchaseRequestSchema.parse(input)
  const issue = await prisma.issue.findUniqueOrThrow({ where:{ id: parsed.issueId } })
  const pr = await prisma.purchaseRequest.create({ data:{ issueId: issue.id, requestedById: 'demo-user', technicianId: issue.assignedToId, items: parsed.items as any, estimate: parsed.estimate, vendor: parsed.vendor } })
  await audit('system','PurchaseRequest', pr.id,'Create', null, pr)
  return pr
}
