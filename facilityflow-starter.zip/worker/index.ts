import { Worker } from 'bullmq'
import IORedis from 'ioredis'
import { PrismaClient } from '@prisma/client'
import { sendEmail } from '../src/lib/email'
const prisma = new PrismaClient()
const connection = new IORedis(process.env.REDIS_URL!)

new Worker('facilityflow', async(job)=>{
  switch(job.name){
    case 'ackReminder':{
      const issue = await prisma.issue.findUnique({ where:{ id: job.data.issueId }, include:{ reporter:true } })
      if (!issue || issue.acknowledgedAt) return
      await sendEmail(issue.reporter.email, `Ack due in 1h – ${issue.title}`, 'Please acknowledge.')
      break
    }
    case 'ackBreach':{
      const issue = await prisma.issue.findUnique({ where:{ id: job.data.issueId } })
      if (!issue || issue.acknowledgedAt) return
      await prisma.issue.update({ where:{ id: issue.id }, data:{ breachAck: true } })
      break
    }
    case 'repairAlert':{
      const issue = await prisma.issue.findUnique({ where:{ id: job.data.issueId }, include:{ assignedTo:true } })
      if (!issue || ['Resolved','Closed'].includes(issue.status)) return
      if (issue.assignedTo) await sendEmail(issue.assignedTo.email, `Repair alert – ${issue.title}`, 'Complete or set ETA.')
      break
    }
    case 'etaOverdue':{
      const issue = await prisma.issue.findUnique({ where:{ id: job.data.issueId } })
      if (!issue || !issue.etaAt || new Date() <= issue.etaAt) return
      await prisma.issue.update({ where:{ id:issue.id }, data:{ breachRepair: true } })
      break
    }
  }
}, { connection })
