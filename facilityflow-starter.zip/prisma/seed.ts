import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

const DEPARTMENTS = [
  'Operations','Facilities','Kitchen','Logistics','IT','Cleaning','Hygiene and Safety'
]
const AREAS = [
  'Reception','Cold Kitchen','Hot kitchen','Packaging','Pastry kitchen','Consultation Rooms','Guest Washroom','Kitchen Staff Washroom','Admin staff Washroom Male','Admin staff Washroom Female','Receiving Area','Admin Offices','CEO Office','Studio','Pathway kitchen','Pathway Facility'
]

async function main(){
  for (const name of DEPARTMENTS) await prisma.department.upsert({ where:{name}, update:{}, create:{name} })
  for (const name of AREAS) await prisma.area.upsert({ where:{name}, update:{}, create:{name} })

  const ops = await prisma.department.findFirstOrThrow({ where:{ name:'Operations' }})
  const fac = await prisma.department.findFirstOrThrow({ where:{ name:'Facilities' }})

  await prisma.user.upsert({ where:{ email:'admin@facilityflow.local' }, update:{}, create:{ name:'Admin', email:'admin@facilityflow.local', role:'Admin' } })
  await prisma.user.upsert({ where:{ email:'ops@facilityflow.local' }, update:{}, create:{ name:'Ops Manager', email:'ops@facilityflow.local', role:'OperationsManager', departmentId: ops.id } })
  await prisma.user.upsert({ where:{ email:'fac-mgr@facilityflow.local' }, update:{}, create:{ name:'Facilities Manager', email:'fac-mgr@facilityflow.local', role:'DepartmentManager', departmentId: fac.id } })
  await prisma.user.upsert({ where:{ email:'tech1@facilityflow.local' }, update:{}, create:{ name:'Tech One', email:'tech1@facilityflow.local', role:'Technician', departmentId: fac.id } })
}
main().finally(()=>prisma.$disconnect())
